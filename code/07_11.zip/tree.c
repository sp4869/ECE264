#include "tree.h"
#include <stdlib.h>
static TreeNode * TreeNode_construct ( int val )
{
	TreeNode * tn;
	tn = malloc ( sizeof ( TreeNode ));
	tn -> left = NULL ;
	tn -> right = NULL ;
	tn -> value = val ;
	return tn;
}
TreeNode * Tree_insert ( TreeNode * tn , int val )
{
	if (tn == NULL )
	{
		// empty , create a node
		return TreeNode_construct ( val );
	}
	// not empty
	if ( val == (tn -> value ))
	{
		// do not insert the same value
		return tn;
	}
	if ( val < (tn -> value ))
	{
		tn -> left = Tree_insert (tn -> left , val );
	}
	else
	{
		tn -> right = Tree_insert (tn -> right , val );
	}
	return tn;
}

TreeNode * Tree_search ( TreeNode * tn , int val )
{
	if (tn == NULL )
	{
		// cannot find
		return NULL ;
	}
	if ( val == (tn -> value ))
	{
		// found
		return tn;
	}
	if ( val < (tn -> value ))
	{
		// search the left side
		return Tree_search (tn -> left , val );
	}
	return Tree_search (tn -> right , val );
}


static void TreeNode_print ( TreeNode *tn)
{
	printf ("%d ",tn -> value );
}

static void Tree_printPreorder ( TreeNode *tn)
{
	if (tn == NULL )
	{
	return ;
	}
	TreeNode_print (tn);
	Tree_printPreorder (tn -> left );
	Tree_printPreorder (tn -> right );
}

static void Tree_printInorder ( TreeNode *tn)
{
	if (tn == NULL )
	{
	return ;
	}
	Tree_printInorder (tn -> left );
	TreeNode_print (tn);
	Tree_printInorder (tn -> right );
}

static void Tree_printPostorder ( TreeNode *tn)
{
	if (tn == NULL )
	{
	return ;
	}
	Tree_printPostorder (tn -> left );
	Tree_printPostorder (tn -> right );
	TreeNode_print (tn);
}
void Tree_print ( TreeNode *tn)
{
	printf ("\n\n ===== Preorder =====\n");
	Tree_printPreorder (tn);
	printf ("\n\n ===== Inorder =====\n");
	Tree_printInorder (tn);
	printf ("\n\n ===== Postorder =====\n");
	Tree_printPostorder (tn);
	printf ("\n\n");
}

int main (int argc, char ** argv){

	TreeNode * root = NULL;
	Tree_insert(root,5);
	Tree_insert(root,3);
	Tree_insert(root,7);
	Tree_insert(root,9);
	Tree_insert(root,1);
	Tree_print(root);
	
	return EXIT_SUCCESS;

}
