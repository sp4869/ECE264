#include "example01.h" //What happens if we include both example02.h and example01.h in example02.c?

