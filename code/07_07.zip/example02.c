#include <stdlib.h>
#include <stdio.h>
#include "example01.h"
#include "example02.h"

/* 
 * If we don't have the #ifndef...#define...#endif statement
 * in example01.h, compiler will complain about multiple definitions
 */


int main(int argc, char ** argv){

	printf("Hello World!");
	Node * ptr = NULL;
	ptr = List_insert_stack(ptr, 2);
	printf("%d\n",ptr->value);

	Node * head1 = NULL;
	Node * head2 = NULL;
	Node * head3 = NULL;

	head1 = List_insert_stack(head1, 8);
	head1 = List_insert_stack(head1, 5);
	head1 = List_insert_stack(head1, 10);
	List_print(head1);
	
	head2 = List_insert_queue(head2, 8);
	head2 = List_insert_queue(head2, 5);
	head2 = List_insert_queue(head2, 10);
	List_print(head2);

	head3 = List_insert_sorted(head3, 8);
	head3 = List_insert_sorted(head3, 5);
	head3 = List_insert_sorted(head3, 10);
	List_print(head3);
	
	List_destroy(head1);
	List_destroy(head2);
	List_destroy(head3);
	
	return EXIT_SUCCESS;


}
